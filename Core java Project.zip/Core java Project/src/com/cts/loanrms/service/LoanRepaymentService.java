package com.cts.loanrms.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;


import com.cts.loanrms.dao.LoanInstallmtDAO;
import com.cts.loanrms.exception.LoanRepaymentException;
import com.cts.loanrms.model.LoanInstallmentPyt;
import com.cts.loanrms.util.ApplicationUtil;



public class LoanRepaymentService {

	LoanInstallmtDAO loanInstallmentDAO = new LoanInstallmtDAO();
	public static ArrayList <LoanInstallmentPyt> buildLoanInstallmentPytList(List <String> loanInstPytRecords) {
		
		
		final String COMMADELIMITER = ",";
		ArrayList <LoanInstallmentPyt> loanInstPytList = new ArrayList<LoanInstallmentPyt>();
		
		// TYPE YOUR CODE HERE
		ApplicationUtil util = new ApplicationUtil();
		
		 
		for(String s:loanInstPytRecords) {
			String [] splt=s.split(COMMADELIMITER);
			LoanInstallmentPyt loanInstallmentPyt =new LoanInstallmentPyt();
			loanInstallmentPyt.setPytId(splt[0]);
			loanInstallmentPyt.setCustomerId(splt[1]);
			loanInstallmentPyt.setLoanId(splt[2]);
			loanInstallmentPyt.setCustomerName(splt[3]);
			loanInstallmentPyt.setLoanType(splt[4]);
			loanInstallmentPyt.setInstallmentAmtInRs(Double.parseDouble(splt[5]));
			loanInstallmentPyt.setDueDate(util.stringToDateConverter(splt[6]));
			loanInstallmentPyt.setActualPytDate(util.stringToDateConverter(splt[7]));
			loanInstallmentPyt.setLoanAmount(Double.parseDouble(splt[9]));
			loanInstPytList.add(loanInstallmentPyt);
		}
		
		return loanInstPytList;
	}
	
	public boolean addLoanInstallmentPytDetails(String inputFeed) throws LoanRepaymentException  {
	
		try {
		List<String> list=	ApplicationUtil.readFile(inputFeed);
		ArrayList<LoanInstallmentPyt> list1=buildLoanInstallmentPytList(list);
		LoanInstallmtDAO dao=new LoanInstallmtDAO();
		dao.insertLoanInstallmentPyt(list1);
		System.out.println("Success");
		return true;
		} catch (LoanRepaymentException | IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
			return false;
	}
	public static double calculateDiscountedInstallment(String loanType,double loanAmount,double currentInstallmentAmt) {
		double revisedInstallmentAmt=0.0;
		
		switch(loanType) {
		case "HousingLoan":if(loanAmount>=1000000 && loanAmount<=2500000) {
			revisedInstallmentAmt =(currentInstallmentAmt)-currentInstallmentAmt*10/100;
		}
		else if(loanAmount>=2500001 && loanAmount<=5000000) {
			revisedInstallmentAmt=(currentInstallmentAmt)-currentInstallmentAmt*12/100;
		}
		else if( loanAmount>5000000) {
			revisedInstallmentAmt=(currentInstallmentAmt)-currentInstallmentAmt*14/100;
		}
		break;
		case "PersonalLoan":if(loanAmount>=50000 && loanAmount<=100000) {
			revisedInstallmentAmt=(currentInstallmentAmt)-currentInstallmentAmt*8/100;
		}
		else if(loanAmount>=100001 && loanAmount<=500000) {
			revisedInstallmentAmt=(currentInstallmentAmt)-currentInstallmentAmt*10/100;
		}
		else if(loanAmount>=500001 && loanAmount<=1000000) {
			revisedInstallmentAmt=(currentInstallmentAmt)-currentInstallmentAmt*12/100;
		}
		break;
		case "VehicleLoan":if(loanAmount>=100000 && loanAmount<=500000) {
			revisedInstallmentAmt=(currentInstallmentAmt)-currentInstallmentAmt*8/100;
		}
		else if (loanAmount>=500001 && loanAmount<=1000000) {
			revisedInstallmentAmt=(currentInstallmentAmt)-currentInstallmentAmt*10/100;
		}
		else if(loanAmount>1000000) {
			revisedInstallmentAmt=(currentInstallmentAmt)-currentInstallmentAmt*12/100;
		}
		break;
		case "EducationLoan":if (loanAmount>=100000 && loanAmount<=500000) {
			revisedInstallmentAmt=(currentInstallmentAmt)-currentInstallmentAmt*11/100;
		}
		else if (loanAmount>=500001 && loanAmount<=1000000) {
			revisedInstallmentAmt=(currentInstallmentAmt)-currentInstallmentAmt*12/100;
		}
		else if(loanAmount>=1000000) {
			revisedInstallmentAmt=(currentInstallmentAmt)-currentInstallmentAmt*13/100;
		}
		break;
		default:System.out.println("There is no loan for this loan type");
		break;
		}
		
		
		return Math.round(revisedInstallmentAmt);
	}
	
	
}
