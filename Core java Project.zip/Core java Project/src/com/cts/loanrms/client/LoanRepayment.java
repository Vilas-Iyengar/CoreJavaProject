package com.cts.loanrms.client;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.cts.loanrms.exception.LoanRepaymentException;
import com.cts.loanrms.util.ApplicationUtil;

public class LoanRepayment {

	public static void main(String[] args) throws LoanRepaymentException, IOException, ParseException {
		// TODO Auto-generated method stub
		String date1="2022-12-23";
		String date2="2022-12-20";
		SimpleDateFormat format=new SimpleDateFormat("yyyy-mm-dd");
		Date dueDate=format.parse(date1);
		Date  ptDate=format.parse(date2);
		
		
		
		
		
		
	System.out.println(ApplicationUtil.checkIfDateOfPytIsLessThanDueDate(ptDate, dueDate));
	}
}
