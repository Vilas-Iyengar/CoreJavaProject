package com.cts.loanrms.client;

import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.cts.loanrms.dao.DBConnectionManager;
import com.cts.loanrms.exception.LoanRepaymentException;
import com.cts.loanrms.service.LoanRepaymentService;
import com.cts.loanrms.util.ApplicationUtil;

public class LoanRepayment {

	public static void main(String[] args) throws LoanRepaymentException, IOException, ParseException, SQLException {
		// TODO Auto-generated method stub
		
		LoanRepaymentService loan=new LoanRepaymentService();
		loan.addLoanInstallmentPytDetails("C:\\Users\\Vilas_venugopal\\Desktop\\New folder (2)\\Loan Automation\\LoanRepaymentMgmtSystemSkel\\src\\inputfeed.txt");
	//	System.out.println(LoanRepaymentService.calculateDiscountedInstallment("HousingLoan", 2000000, 20345));
		
		
		
		
	//System.out.println(ApplicationUtil.readFile("C:\\Users\\Vilas_venugopal\\Desktop\\New folder (2)\\Loan Automation\\LoanRepaymentMgmtSystemSkel\\src\\inputfeed.txt"));
	}
}
