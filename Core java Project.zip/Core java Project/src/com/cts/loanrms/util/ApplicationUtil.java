package com.cts.loanrms.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.cts.loanrms.exception.LoanRepaymentException;







public class ApplicationUtil {


	public static List<String> readFile(String inputfeed) throws LoanRepaymentException, IOException {
		List<String> loanInstPytList = new ArrayList<String>();
		
		// TYPE YOUR CODE HERE
		String line;
		File file=new File(inputfeed);
		if(file.exists() && file.isFile()&& file.getName().endsWith(".txt"))
		{
			BufferedReader reader =new BufferedReader(new FileReader(file));
			while((line=reader.readLine())!=null) {
				loanInstPytList.add(line);
			}
		}
		else
			System.out.println("File not Found");
		

		return loanInstPytList;
	}
	public static java.sql.Date utilToSqlDateConverter(java.util.Date utDate) {
		java.sql.Date sqlDate = null;
		SimpleDateFormat format=new SimpleDateFormat("yyyy-mm-dd");
		String date=format.format(utDate);
		sqlDate=java.sql.Date.valueOf(date);
		
		// TYPE YOUR CODE HERE
		
		return sqlDate;
	}
	
	public static java.util.Date stringToDateConverter(String stringDate) {
		
		// TYPE YOUR CODE HERE
		SimpleDateFormat format=new SimpleDateFormat("yyyy-mm-dd");
		Date date=new Date();
		try {
			 date=format.parse(stringDate);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
				
		return date;
	}
	
	public static boolean checkIfDateOfPytIsLessThanDueDate(Date dateOfPyt,Date dueDate)
	{
		//Date dtOPfyt,actDueDt;
		boolean eligibility=false;
		double difInMSeconds=0.0;
		double days=0.0;
		//Write the logic here to compare and see if the payment date is 20 days or more to due date
		
		SimpleDateFormat format=new SimpleDateFormat("yyyy-mm-dd");
		String date=format.format(dueDate);
		String date1=format.format(dateOfPyt);
		System.out.println((date.compareTo(date1)));
		
		return eligibility;
	}
}
