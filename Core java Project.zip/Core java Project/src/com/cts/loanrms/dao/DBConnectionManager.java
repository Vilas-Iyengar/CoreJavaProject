package com.cts.loanrms.dao;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.cts.loanrms.exception.LoanRepaymentException;



public class DBConnectionManager {
	private static final String DB_DRIVER_CLASS="drivername";
	private static final String DB_USERNAME="username";
	private static final String DB_PASSWORD="password";
	private static final String DB_URL="url";
	private static  Properties properties=null;

	 
	 private static Connection con = null;
	 private static DBConnectionManager instance; 
	private  DBConnectionManager()  throws LoanRepaymentException
	{
		 try {
			FileInputStream fis=new FileInputStream("C:\\Users\\Vilas_venugopal\\Desktop\\New folder (2)\\Loan Automation\\LoanRepaymentMgmtSystemSkel\\src\\database.properties");
		    properties =new Properties();
			properties.load(fis);
			System.out.println(properties.getProperty(DB_DRIVER_CLASS));
			
			Class.forName(properties.getProperty(DB_DRIVER_CLASS));
			con=DriverManager.getConnection(properties.getProperty(DB_URL),properties.getProperty(DB_USERNAME),properties.getProperty(DB_PASSWORD));
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		
	}
	public static DBConnectionManager getInstance() throws LoanRepaymentException {
		
		instance=new DBConnectionManager();

		return instance;
	}
	public Connection getConnection() throws SQLException {
		try {
			Class.forName(properties.getProperty(DB_DRIVER_CLASS));
			con=DriverManager.getConnection(properties.getProperty(DB_URL),properties.getProperty(DB_USERNAME),properties.getProperty(DB_PASSWORD));
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return con;
	}
}
