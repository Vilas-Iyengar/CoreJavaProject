package com.cts.loanrms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;


import com.cts.loanrms.exception.LoanRepaymentException;
import com.cts.loanrms.model.LoanInstallmentPyt;
import com.cts.loanrms.util.ApplicationUtil;



public class LoanInstallmtDAO {
	public static Connection connection,connection1 = null;

	public boolean insertLoanInstallmentPyt(ArrayList <LoanInstallmentPyt> loanInstlmtPyts) throws LoanRepaymentException {
		boolean recordsAdded = false;
		PreparedStatement lPytInsert = null;

		// TYPE YOUR CODE HERE
		
		return recordsAdded;
	}
	
}
