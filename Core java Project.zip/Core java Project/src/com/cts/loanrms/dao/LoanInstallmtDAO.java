package com.cts.loanrms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;

import com.cts.loanrms.exception.LoanRepaymentException;
import com.cts.loanrms.model.LoanInstallmentPyt;
import com.cts.loanrms.service.LoanRepaymentService;
import com.cts.loanrms.util.ApplicationUtil;



public class LoanInstallmtDAO {
	public static Connection connection = null;
	
	DBConnectionManager con;

	public boolean insertLoanInstallmentPyt(ArrayList <LoanInstallmentPyt> loanInstlmtPyts) throws LoanRepaymentException {
		boolean recordsAdded = false;
		try {
			con=DBConnectionManager.getInstance();
			connection=con.getConnection();
			PreparedStatement lPytInsert = connection.prepareStatement("insert into loaninstallment values(?,?,?,?,?,?,?,?,?,?)");
			for(int i=0;i<loanInstlmtPyts.size();i++) {
				LoanInstallmentPyt loans=loanInstlmtPyts.get(i);
				System.out.println(loans.getPytId());
				lPytInsert.setString(1, loans.getPytId());
				lPytInsert.setString(2,loans.getCustomerId());
				lPytInsert.setString(3, loans.getLoanId());
				lPytInsert.setString(4, loans.getCustomerName());
				lPytInsert.setString(5, loans.getLoanType());
				lPytInsert.setDouble(6,loans.getInstallmentAmtInRs());
				lPytInsert.setDate(7, ApplicationUtil.utilToSqlDateConverter(loans.getDueDate()));
				lPytInsert.setDate(8, ApplicationUtil.utilToSqlDateConverter(loans.getActualPytDate()));
				lPytInsert.setDouble(9, LoanRepaymentService.calculateDiscountedInstallment(loans.getLoanType(),loans.getLoanAmount(),loans.getInstallmentAmtInRs()));
				lPytInsert.setDouble(10, loans.getLoanAmount());
				int index=lPytInsert.executeUpdate();
				if(i>0)
					recordsAdded=true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		
		
		return recordsAdded;
	}
	
}
