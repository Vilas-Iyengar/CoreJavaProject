package com.pod5.smartbuy.service;

import com.pod5.smartbuy.model.User;

public interface UserService {

	boolean saveUser(User user);

	User findUserByEmail(String email);

}
