package com.pod5.smartbuy.service;

import com.pod5.smartbuy.model.Cart;

public interface CartService {
	
	boolean saveCart(Cart cart);
	boolean updateCart(Cart cart);
	
	Cart findCart();

}
