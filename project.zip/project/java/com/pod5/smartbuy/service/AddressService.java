package com.pod5.smartbuy.service;

import com.pod5.smartbuy.model.Address;

public interface AddressService {

	boolean saveAddress(Address address);
	Address findAddressByBilling(boolean billing);

}
